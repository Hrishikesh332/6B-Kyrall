# 8-marker wall organizer

Prototype generated in local workshop mode.

## Specification

- 8 markers; barrel diameter 18 mm; diametral clearance 1 mm.
- Two screws; Caps up; intended material PETG.
- One connected part; print on its back. Confirm overhangs in slicer; supports may be required.
- Wall fasteners and anchors are not supplied or load rated.
- STEP contains editable solid geometry; the JSON recipe preserves construction parameters.

## Files and validation

Assembly envelope: 200.0 × 29.002 × 52.0 mm. 1 component(s).

The validation report records B-rep validity, connected solids, watertightness, winding, volume, build-volume fit, interferences, and STEP reimport. These checks passed.

STL coordinates are in millimetres. Import them using mm units. STEP contains editable solids, not native feature history. The .cad.json file preserves the construction recipe; rebuild it with the local CAD endpoint.

## Printing and assembly

Review the supplied print orientation in a slicer. Use a small fit coupon before a full print. Check support requirements and layer direction. For the marker organizer, dry-fit the barrels before mounting. For screw mounting use suitable screws and anchors for the actual wall; no wall capacity is asserted. Adhesive mounting requires a separately selected, load-rated strip and a clean compatible wall.

## Limits

No physical test, load calculation, motion simulation, automated wall-thickness analysis, or automated visual approval was performed. The four SVG views and interactive mesh are provided for review. Materials are documentation assumptions; no material solver is implemented.
